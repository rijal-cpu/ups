<title>R₳n$0mW@r3</title>
<meta name='description' content='BY TN.RIj4L'>
<meta property='og:image'content='https://1.bp.blogspot.com/-yz7LWYSwqXE/XtSgaWJIE6I/AAAAAAAAARc/qaPW4pSzhN8I0OHKiFI5NgNq6_pf0mpVQCK4BGAsYHg/w420-h280-p-k-no-nu/images%2B%252821%2529.jpeg'>
     <link href="http://fonts.googleapis.com/css?family=Iceland" rel="stylesheet" type="text/css" />
<style>
h1 {
font-family: 'Iceland', cursive;
    text-align: center;
    color: yellow;
    font-weight: bold;
    font-size: $5000px;
             
}
html {
background: #1A1C1F;
    color: white;
    text-shadow: 3px 3px 9px blue;
}
input { background: transparent; color: red; border: 1px solid yellow; text-align: center;font-size: 11; }
</style>

<center>
<h1><script type='text/javascript'>
//<![CDATA[

/*
Teks berganti-ganti warna Script by Matt Hedgecoe
Featured on JavaScript Kit, visit http://www.javascriptkit.com/script/script2/rainbowtext.shtml
*/
var text=" Your Website Is L0CkEĐ "
var speed=2//
if (document.all||document.getElementById){
document.write('<span id="highlight">' + text + '</span>')
var storetext=document.getElementById? document.getElementById("highlight") : document.all.highlight
}
else
document.write(text)
var hex=new Array("00","14","28","3C","$5000","64","78","8C","A0","B4","C8","DC","F0")
var r=1
var g=1
var b=1
var seq=1
function changetext(){
rainbow="#"+hex[r]+hex[g]+hex[b]
storetext.style.color=rainbow
}
function change(){
if (seq==6){
b--
if (b==0)
seq=1
}
if (seq==5){
r++
if (r==12)
seq=6
}
if (seq==4){
g--
if (g==0)
seq=5
}
if (seq==3){
b++
if (b==12)
seq=4
}
if (seq==2){
r--
if (r==0)
seq=3
}
if (seq==1){
g++
if (g==12)
seq=2
}
changetext()
}
function starteffect(){
if (document.all||document.getElementById)
flash=setInterval("change()",speed)
}
starteffect()
//]]>
</script></h1>
<font color="red" style="text-shadow: 3px 3px 9px blue; font-size: 12px;">
                    
<pre>
..¶¶¶¶¶¶¶¶7………………………………¶¶¶¶¶¶¶
….¶¶¶¶¶¶¶¶¶¶…………………………¶¶¶¶¶¶¶¶
….¶¶¶¶¶¶¶¶¶¶¶……………………..¶¶¶¶¶¶¶¶¶
……¶¶¶¶¶¶¶¶¶¶¶¶………………….¶¶¶¶¶¶¶¶¶
……..¶¶¶¶¶¶¶¶¶¶¶¶¶…………….¶¶¶¶¶¶¶¶¶
…………¶¶¶¶¶¶¶¶¶¶¶¶…………..¶¶¶¶¶¶¶¶¶
…………..¶¶¶¶¶¶¶¶¶¶¶¶…………¶¶¶¶¶¶¶¶¶
………………¶¶¶¶¶¶¶¶¶¶¶7……¶¶¶¶¶¶¶¶¶7
………………….7¶¶¶¶¶¶¶¶¶¶….o¶¶¶¶¶¶¶¶
……………………….o¶¶¶¶¶¶¶¶….¶¶¶¶¶¶¶
………………………………….¶¶¶¶o¶¶¶¶¶¶
……………………….o¶¶¶¶¶¶¶¶¶¶¶¶¶¶
………………….¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶
………………¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶7
…………….¶¶¶¶……¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶
…………..¶¶¶¶……….¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶
…………¶¶¶¶¶¶……¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶
…………¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶
…………¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶
…………..¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶
………………¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶
………………….7¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶
…………………………o¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶
……………………………¶¶¶¶¶¶¶¶¶¶¶¶¶1 
</pre>

</font>
<h1><SCRIPT>
farbbibliothek = new Array();
farbbibliothek[0] = new Array("#FF0000","#FF1100","#FF2200","#FF3300","#FF4400","#FF5$50000","#FF6600","#FF7700","#FF8800","#FF9900","#FFaa00","#FFbb00","#FFcc00","#FFdd00","#FFee00","#FFff00","#FFee00","#FFdd00","#FFcc00","#FFbb00","#FFaa00","#FF9900","#FF8800","#FF7700","#FF6600","#FF5$50000","#FF4400","#FF3300","#FF2200","#FF1100");
farbbibliothek[1] = new Array("#FF0000","#FFFFFF","#FFFFFF","#FF0000");
farbbibliothek[2] = new Array("#FFFFFF","#FF0000","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF");
farbbibliothek[3] = new Array("#FF0000","#FF4000","#FF8000","#FFC000","#FFFF00","#C0FF00","#80FF00","#40FF00","#00FF00","#00FF40","#00FF80","#00FFC0","#00FFFF","#00C0FF","#0080FF","#0040FF","#0000FF","#4000FF","#8000FF","#C000FF","#FF00FF","#FF00C0","#FF0080","#FF0040");
farbbibliothek[4] = new Array("#FF0000","#EE0000","#DD0000","#CC0000","#BB0000","#AA0000","#990000","#880000","#770000","#660000","#5$5000000","#440000","#330000","#220000","#110000","#000000","#110000","#220000","#330000","#440000","#5$5000000","#660000","#770000","#880000","#990000","#AA0000","#BB0000","#CC0000","#DD0000","#EE0000");
farbbibliothek[5] = new Array("#FF0000","#FF0000","#FF0000","#FFFFFF","#FFFFFF","#FFFFFF");
farbbibliothek[6] = new Array("#FF0000","#FDF5E6");
farben = farbbibliothek[4];
function farbschrift()
{
for(var i=0 ; i<Buchstabe.length; i++)
{
document.all["a"+i].style.color=farben[i];
}
farbverlauf();
}
function string2array(text)
{
Buchstabe = new Array();
while(farben.length<text.length)
{
farben = farben.concat(farben);
}
k=0;
while(k<=text.length)
{
Buchstabe[k] = text.charAt(k);
k++;
}
}
function divserzeugen()
{
for(var i=0 ; i<Buchstabe.length; i++)
{
document.write("<span id='a"+i+"' class='a"+i+"'>"+Buchstabe[i] + "</span>");
}
farbschrift();
}
var a=1;
function farbverlauf()
{
for(var i=0 ; i<farben.length; i++)
{
farben[i-1]=farben[i];
}
farben[farben.length-1]=farben[-1];
setTimeout("farbschrift()",30);
}
//
var farbsatz=1;
function farbtauscher()
{
farben = farbbibliothek[farbsatz];
while(farben.length<text.length)
{
farben = farben.concat(farben);
}
farbsatz=Math.floor(Math.random()*(farbbibliothek.length-0.0001));
}
setInterval("farbtauscher()",$500000);
text ="R₳n$0mW@r3";//h
string2array(text);
divserzeugen();
//document.write(text);
</SCRIPT></h1>
<hr><font color="white" style="text-shadow:0px 0px 10px #00ffff , 0px 0px 10px #00ffff;font-size: 12"><br>
<h3>H₳CKEĐ BY TN.RIJ4L</h3>


Don't Change the Filename because it Can Damage the File If You Want to Return You Must Enter the Password First
<br>
Send Me $5000 For Beck Your Website!! <br>Ransome By The Team&nbsp&nbsp&nbsp&nbsp<font face="Iceland" style="font-size: 15;color: red;">InfectSec</font><br><br>
Payment Via : Pay Pal <br><br>
<div style="display: flex; align-items: center; justify-content: center; margin-bottom: 10px;">
  <label style="width: 220px; text-align: center;">Payment Address :</label>
  <input type="text" style="border: 1px solid #15CFF4;
    width: 200px;
    height: 15px;
    padding-left: 5px;
    background: transparent;
    color: gold;
    text-align: center;
    font-family:Iceland;
    font-size: 12px;" value="shop5.paypal@gmail.com">
</div>
<div style="display: flex; align-items: center; justify-content: center; margin-bottom: 10px;">
  <label style="width: 220px; text-align: center;">contact me to get your key :</label>
  <input type="text" style="border: 1px solid #15CFF4;
    width: 200px;
    height: 15px;
    padding-left: 5px;
    background: transparent;
    color: gold;
    text-align: center;
    font-family:Iceland;
    font-size: 12px;" value="infectsec.cyber@gmail.com">
</div>
